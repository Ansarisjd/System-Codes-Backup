package StepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class loginStepDefinition {

	@Given("user is on login page")
	public void user_is_on_login_page() {
	    System.out.println("user is on login page");
	}

	@When("User enter login id")
	public void user_enter_login_id() {
		System.out.println("User enter login id");
	}

	@And("User enter password")
	public void user_enter_password() {
		System.out.println("User enter password");
	}

	@Then("User able to login successfully into the system")
	public void user_able_to_login_successfully_into_the_system() {
		System.out.println("User able to login successfully into the system");
	}

	
}
