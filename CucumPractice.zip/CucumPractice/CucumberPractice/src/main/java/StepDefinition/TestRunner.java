package StepDefinition;



import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = "src/test/resources/features/login.feature" , glue= {"StepDefinition"} ,
plugin = {
        "html:C:\\Users\\Divyesh Pawaskar\\Documents\\Sajid Ansari\\CucumPractice\\CucumberPractice\\test-output\\Reports\\test.html"
    }	)
public class TestRunner extends AbstractTestNGCucumberTests{
	
	
}

