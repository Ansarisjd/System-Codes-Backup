package PyramidPatternInJava;

import java.util.Scanner;

public class PyramidPatern1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the rows to print:");
		int rows = sc.nextInt();
		// System.out.println("Rows = "+rows);
		sc.close();

		System.out.println("Printing Pattern 1\n"); 
		printPattern(rows);

	}
	
	private static void printPattern(int rows) {
		for(int i=1; i<=rows; i++) {
			int numberOfWhiteSpaces = rows -i;
			printString(" " ,numberOfWhiteSpaces );
			printString(i + " ", i);
			System.out.println("");
		}
	}
	
	private static void printString(String s, int times) {
		for (int j = 0; j < times; j++) {
			System.out.print(s);
			
		}
	}

}
