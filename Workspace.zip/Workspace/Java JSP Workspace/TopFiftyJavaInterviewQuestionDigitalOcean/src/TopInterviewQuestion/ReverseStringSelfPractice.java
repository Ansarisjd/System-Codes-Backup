package TopInterviewQuestion;

public class ReverseStringSelfPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   String A = "TDBoka";
   System.out.println(ReverseString(A));
	}

	public static String ReverseString(String in) {
		StringBuilder stringBuilder = new StringBuilder();
		char[] chararray = in.toCharArray();
		for(int i = in.length()-1; i>= 0; i--) {
			stringBuilder.append(chararray[i]);
		}
		 return stringBuilder.toString();
		 
	}
	
}
