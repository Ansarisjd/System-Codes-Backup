package TopInterviewQuestion;

public class SwapTwoNoWithUsingThirdVariable {

//	2. How do you swap two numbers without using a third variable in Java?
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int a = 3;
	int b = 4;
	
	a = a+b;
	b = a-b;
	a = a-b;
	System.out.println("Value of a is:" +a);
	System.out.println("Value of b is:" +b);	
		
	}
	

}
