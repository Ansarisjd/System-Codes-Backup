package TopInterviewQuestion;

public class ReverseString {

	
	//  1)  How do you reverse a string in Java?
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Sajid Ansari";

		System.out.println(reverse(str));
		
	}


	
	public static String reverse(String in) {
		StringBuilder out = new StringBuilder();
		char[] chars = in.toCharArray();
		for(int i = in.length() - 1; i >=0 ;i--) {
			out.append(chars[i]);
		}
		
		
		return out.toString();
		
	}
	
	
	
}
