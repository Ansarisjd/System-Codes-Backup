package TopInterviewQuestion;

public class FactorialOfAnInteger {

	public static void main(String[] args) {
		System.out.println(factor(3));

	}
	
	
	public static long factor(long n) {
		if(n == 1) {
			return 1;
		}
		else {
			return (n * factor(n-1));
		}
		
	}

}
