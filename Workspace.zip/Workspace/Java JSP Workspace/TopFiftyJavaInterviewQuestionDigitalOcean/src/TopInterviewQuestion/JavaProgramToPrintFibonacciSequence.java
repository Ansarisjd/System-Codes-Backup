package TopInterviewQuestion;

public class JavaProgramToPrintFibonacciSequence {

	public static void main(String[] args) {
		FibunacciSeq(10);

	}
	
	public static int FibunacciSeq(int input) {
		int a = 0;
		int b = 1;
		int c = 1;
		
		for(int i = 0; i<=input; i++) {
			System.out.println(a + " ");
			a = b;
			b = c;
			c = a + b;
			
		
			
		}
		return a;
		
		
		
		
	}

}
