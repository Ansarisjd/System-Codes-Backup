package TopInterviewQuestion;

public class RemoveSpacesFromString {

	public static void main(String[] args) {
		System.out.println(RemoveSpaces("Sajid Ansari"));

	}
	
	public static String RemoveSpaces(String input) {
		StringBuilder a = new StringBuilder();
		char[] b =  input.toCharArray();
		for (char c : b ) {
			if(!Character.isWhitespace(c))
				a.append(c);
		}
		
		return a.toString();
	}

}
