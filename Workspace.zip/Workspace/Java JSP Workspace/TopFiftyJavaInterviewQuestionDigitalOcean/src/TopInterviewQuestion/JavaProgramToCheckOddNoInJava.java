package TopInterviewQuestion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JavaProgramToCheckOddNoInJava {

	public static void main(String[] args) {
		List<Integer> IntegerList = new ArrayList<>();
		IntegerList.addAll(Arrays.asList(2,4,6,8,9));
		
		System.out.println(IsOddNumber(IntegerList));
       
      
	}

	public static boolean IsOddNumber(List<Integer> list) {
		for(int i = 0 ; i <=list.size(); i++ ) {
			if( i % 2 == 0) 
				return false;
			}
			return true;
		
	}
}
		
		
	
