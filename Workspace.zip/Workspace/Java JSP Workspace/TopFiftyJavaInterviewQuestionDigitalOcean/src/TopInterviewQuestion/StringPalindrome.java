package TopInterviewQuestion;

public class StringPalindrome {

	public static void main(String[] args) {
		System.out.println(IsPalindrome("OYO"));

	}
	
	public static boolean IsPalindrome(String Input) {
		StringBuilder a = new StringBuilder();
		char[] b = Input.toCharArray();
		for(int i = Input.length()-1; i>= 0 ; i-- ) {
		a.append(b[i]);
		}
		String d = a.toString();
		if(Input.equalsIgnoreCase(d)) {
			return true;
		}
		return false;
	}

}
