package TopInterviewQuestion;

public class JavaProgramToRemoveLeadingAndTrailingSpaces {

	public static void main(String[] args) {
		String a = "  Sajid Ansari";
		
		System.out.println(a.strip());
		System.out.println(a.trim().charAt(2));
	}

}
