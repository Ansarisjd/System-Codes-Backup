package TopInterviewQuestion;

public class JavaProgramToCheckWordContainVowels {

	public static void main(String[] args) {
		System.out.println(ContainVowels("ayu"));

	}
	
	public static boolean ContainVowels(String a) {
		return a.toLowerCase().matches(".*[aeiou].*");
		
	}

}
