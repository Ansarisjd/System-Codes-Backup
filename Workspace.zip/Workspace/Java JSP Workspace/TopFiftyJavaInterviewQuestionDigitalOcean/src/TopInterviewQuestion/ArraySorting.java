package TopInterviewQuestion;

import java.util.Arrays;

public class ArraySorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int[] array = {1,2,3,4,-1,-12,-3,5};
    Arrays.sort(array);	
    String d = Arrays.toString(array);
    System.out.println(d);
    
	}

}
